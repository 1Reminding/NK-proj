package com.example.accelerometer;
import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    TextView acceleration_x;//x方向的加速度
    TextView acceleration_y;//y方向的加速度
    TextView acceleration_z;//z方向的加速度
    TextView acceleration_total;//显示总加速度
    //显示运动情况
    TextView ifmove;
    //显示用户步数
    TextView stepCount;
    SensorManager mySensorManager;//SensorManager对象引用
    //SensorManagerSimulator mySensorManager;//声明SensorManagerSimulator对象,调试时用
    @Override
    public void onCreate(Bundle savedInstanceState) {//重写onCreate方法
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//设置当前的用户界面
        acceleration_x = (TextView) findViewById(R.id.acceleration_x);//得到acceleration_x的引用
        acceleration_y = (TextView) findViewById(R.id.acceleration_y);//得到acceleration_y的引用
        acceleration_z = (TextView) findViewById(R.id.acceleration_z);//得到acceleration_z的引用
        acceleration_total = (TextView) findViewById(R.id.acceleration_total);//得到acceleration_total的引用

        //设置一个用于判断是否运动的控件
        ifmove = (TextView) findViewById(R.id.ifmove);//得到ifmove的引用

        stepCount = (TextView) findViewById(R.id.stepCount);

        mySensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);//获得SensorManager
    }
    private static final float THRESHOLD = 10.0f; // 设置阈值为10.0
    private SensorEventListener mySensorListener = new SensorEventListener() {
        private int stepCount_total = 0;
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                float[] values = sensorEvent.values;

                float total_acceleration = (float) Math.sqrt(sensorEvent.values[0] * sensorEvent.values[0]
                        + sensorEvent.values[1] * sensorEvent.values[1]
                        + sensorEvent.values[2] * sensorEvent.values[2]);


                // 使用Low-Pass Filter进行平滑处理
                float alpha = 0.8f;
                float[] gravity = new float[3];

                gravity[0] = alpha * gravity[0] + (1 - alpha) * sensorEvent.values[0];
                gravity[1] = alpha * gravity[1] + (1 - alpha) * sensorEvent.values[1];
                gravity[2] = alpha * gravity[2] + (1 - alpha) * sensorEvent.values[2];

                float linear_acceleration_x = sensorEvent.values[0] - gravity[0];
                float linear_acceleration_y = sensorEvent.values[1] - gravity[1];
                float linear_acceleration_z = sensorEvent.values[2] - gravity[2];

                // 创建DecimalFormat对象，设置保留两位小数
                DecimalFormat df = new DecimalFormat("0.00");

                // 设置加速度的显示情况
                acceleration_x.setText("acceleration_x：" + df.format(linear_acceleration_x));
                acceleration_y.setText("acceleration_y：" + df.format(linear_acceleration_y));
                acceleration_z.setText("acceleration_z：" + df.format(linear_acceleration_z));
                acceleration_total.setText("acceleration_total：" + df.format(total_acceleration));

                // 判断手机是否在运动
                if(total_acceleration < 10.3 && total_acceleration > 9.4){
                    ifmove.setText("At rest" );
                } else if(total_acceleration >= 10.4){
                    if(ifmove.getText()=="In motion,uping" ){
                        stepCount_total++;
                    }
                    ifmove.setText("In motion,downing" );
                } else if(total_acceleration <= 9.3){
                    if(ifmove.getText()=="In motion,downing" ){
                        stepCount_total++;
                    }
                    ifmove.setText("In motion,uping" );
                }


                stepCount.setText("Step Count: " + stepCount_total);
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
        }
    };
    @Override
    protected void onResume() {//重写的onResume方法
        mySensorManager.registerListener(//注册监听
                mySensorListener, //监听器SensorListener对象
                mySensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),//传感器的类型为加速度
                SensorManager.SENSOR_DELAY_UI//传感器事件传递的频度
        );
        super.onResume();
    }
    @Override
    protected void onPause() {//重写onPause方法
        mySensorManager.unregisterListener(mySensorListener);//取消注册监听器
        super.onPause();
    }
}