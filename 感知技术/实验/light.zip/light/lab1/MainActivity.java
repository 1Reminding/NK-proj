/*
package com.example.myapplication;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {

    private SensorManager sensorManager;
    private TextView lightIntensityText;
    private TextView sensorInfoText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        lightIntensityText = findViewById(R.id.light_intensity);
        sensorInfoText = findViewById(R.id.sensor_info);

        Sensor lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        if (lightSensor != null) {
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);

            String sensorInfo = "名称：" + lightSensor.getName() + "\n耗电量（mA）：" + lightSensor.getPower() + "\n最大测量范围：" + lightSensor.getMaximumRange();
            sensorInfoText.setText(sensorInfo);
        } else {
            lightIntensityText.setText("光线传感器不可用");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // 这里不处理精度变化
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_LIGHT) {
            lightIntensityText.setText("光照强度：" + event.values[0] + " lx");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 重新注册监听器，以保证恢复活动时传感器继续工作
        Sensor lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        if (lightSensor != null) {
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
}*/
package com.example.myapplication;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;
import android.util.Log;

public class MainActivity extends Activity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor lightSensor;
    private TextView textLightSensor, textSensorInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textLightSensor = findViewById(R.id.textLightSensor);
        textSensorInfo = findViewById(R.id.textSensorInfo);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        if (lightSensor != null) {
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
            String sensorInfo = "名称: " + lightSensor.getName() + "\n耗电量(mA): " + lightSensor.getPower() +
                    "\n最大测量范围: " + lightSensor.getMaximumRange();
            textSensorInfo.setText(sensorInfo);
        } else {
            textLightSensor.setText("光线传感器不可用");
        }
    }

    @Override
    // 当光线传感器的值发生变化时
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_LIGHT) {
            // 显示光照强度
            textLightSensor.setText("光照强度: " + event.values[0] + " lx");
            adjustScreenBrightness(event.values[0]);// 根据光照强度调整屏幕亮度
        }
    }

    private void adjustScreenBrightness(float lux) {// 根据光照强度调整屏幕亮度的逻辑
        // 将光照强度转换为屏幕亮度值
        float brightness = lux / lightSensor.getMaximumRange();
        brightness = Math.max(0, Math.min(brightness, 1)); // 确保值在0到1之间

        // 应用亮度调整到当前窗口
        WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
        layoutParams.screenBrightness = brightness;
        getWindow().setAttributes(layoutParams);

        // 输出日志,记录两个对照值的变化
        Log.d("ScreenBrightness", "Lux: " + lux + ", Adjusted Brightness: " + brightness);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {//方法体可以为空，光线传感器的精度很少发生变化，即便有变化对应用的影响也很小
        // 记录传感器精度变化的日志
        Log.d("SensorAccuracy", "Sensor: " + sensor.getName() + ", Accuracy changed to: " + accuracy);
    }

    @Override
    // 注册光线传感器监听器
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    // 注销光线传感器监听器
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }





}
